LSMAC QR Code Generator (Windows EXE Version)
=============================================

How to Use:
-----------
1. Unzip this folder on your Windows laptop.
2. Double-click `qr_generator.exe` to launch the QR generator app.
3. The app will open and allow you to generate QR codes for members.

Notes:
------
- You do NOT need to install Python or any other software.
- All member data is stored in Supabase (cloud). No local database is required.
- If you see errors about missing files, make sure `LOGO3.png` is in the same folder as the EXE.
- If you need to update the Supabase URL or key, contact your system administrator for a new version.

Support:
--------
For help, contact your LSMAC system administrator. 